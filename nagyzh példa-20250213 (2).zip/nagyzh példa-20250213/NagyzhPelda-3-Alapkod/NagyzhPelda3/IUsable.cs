﻿namespace NagyzhPelda3;

internal interface IUsable
{
    bool IsActive();
    bool Use();
}
