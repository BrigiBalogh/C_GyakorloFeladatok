﻿namespace NagyzhPelda3;

internal class Purchase
{
}
