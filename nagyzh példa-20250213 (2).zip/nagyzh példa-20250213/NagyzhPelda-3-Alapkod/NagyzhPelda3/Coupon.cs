﻿namespace NagyzhPelda3;

internal abstract class Coupon
{
}
