﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NagyzhPelda3
{
    internal abstract class Coupon
    {
    }
}
