﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle6_kozos
{
    internal class Vehicle
    {
        public int Mass { get; set; }
        public int Speed { get; set; }

        public Vehicle(int mass, int speed)
        {
            Mass = mass;
            Speed = speed;
        }

        public virtual void Print()
        {
            Console.WriteLine($"Tömeg: {Mass}, Sebesség: {Speed}");
        }
    }
}
