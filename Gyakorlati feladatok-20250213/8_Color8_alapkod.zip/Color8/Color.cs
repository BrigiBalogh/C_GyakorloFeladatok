﻿using System;

namespace Color8
{
    internal class Color
    {
    }
}
