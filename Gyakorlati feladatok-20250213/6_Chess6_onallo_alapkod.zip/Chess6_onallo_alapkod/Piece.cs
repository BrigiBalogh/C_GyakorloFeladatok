﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chess6_onallo
{
    internal class Piece
    {
        public string Position { get; set; }

        public Piece(string position)
        {
            Position = position;
        }
    }
}
