﻿using System;
using System.Collections.Generic;

namespace QuestionBankExample
{
    class QuestionBank
    {
        List<Question> _questions = new List<Question>();

        public bool AddQuestion(Question newQuestion)
        {
            foreach (Question question in _questions)
            {
                if (question.Id == newQuestion.Id)
                {
                    Console.WriteLine($"Question ID \"{newQuestion.Id}\" already exists in the database!");
                    return false;
                }
            }
            _questions.Add(newQuestion);
            return true;
        }
        public Question GetQuestionById(string id)
        {
            foreach (Question question in _questions)
            {
                if (question.Id == id) { return question; }
            }
            return null;
        }
    }
}
