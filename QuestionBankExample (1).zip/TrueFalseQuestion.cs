﻿using System;

namespace QuestionBankExample
{
    class TrueFalseQuestion : Question
    {
        private bool _correctAnswer;
        public TrueFalseQuestion(string id, string text, bool correctAnswer):
            base(id, text)
        {
            _correctAnswer = correctAnswer;
        }
        public override bool CheckAnswer(string answer)
        {
            return bool.Parse(answer) == _correctAnswer;
        }
    }
}
