﻿using System;
using System.Collections.Generic;

namespace QuestionBankExample
{
    class Quiz
    {
        List<Question> _questions = new List<Question>();

        public void AddQuestion(Question question)
        {
            _questions.Add(question);
        }

        public int NumberOfQuestions()
        {
            return _questions.Count;
        }
        public int Attempt()
        {
            int correctAnswers = 0;
            foreach (Question question in _questions)
            {
                Console.WriteLine(question.Text);
                string userAnswer = Console.ReadLine();
                bool isCorrect = question.CheckAnswer(userAnswer);
                if (isCorrect) { correctAnswers++; }
            }
            return correctAnswers;
        }
    }
}
