﻿using System.Diagnostics;

namespace QuestionBankExample
{
    internal class Program
    {
        static void AddQuestionToQuizById(Quiz quiz, QuestionBank questionBank, string questionId)
        {
            Question question = questionBank.GetQuestionById(questionId);
            if (question == null)
            {
                Console.WriteLine($"Question with id \"{questionId}\" does not exist");
            }
            else
            {
                quiz.AddQuestion(question);
            }
        }
        static void Main(string[] args)
        {
            QuestionBank questionBank = new QuestionBank();
            questionBank.AddQuestion(new TrueFalseQuestion("class-object 1",
                                            "Are class and object the same?",
                                            false));
            questionBank.AddQuestion(new SingleChoiceQuestion("virtual keyword",
                                            "What is the correct keyword to define a virtual method?",
                                            new List<string> { "new", "abstract", "virtual", "override" },
                                            2));
            questionBank.AddQuestion(new NumericalQuestion("multiply 1",
                                            "What is 2.5*4.2?",
                                            10.5));
            questionBank.AddQuestion(new NumericalQuestion("the answer",
                                            "What is the answer to Life, the Universe, and Everything?",
                                            42));
            questionBank.AddQuestion(new TrueFalseQuestion("do-you",
                                            "Do you understand programming?",
                                            true));
            questionBank.AddQuestion(new NumericalQuestion("multiply 2",
                                            "What is 9.9*10?",
                                            99));

            Quiz quiz = new Quiz();
            AddQuestionToQuizById(quiz, questionBank, "class-object 1");
            AddQuestionToQuizById(quiz, questionBank, "multiply 2");
            AddQuestionToQuizById(quiz, questionBank, "virtual keyword");

            int successCount = quiz.Attempt();
            Console.WriteLine($"You have successfully answered {successCount} out of {quiz.NumberOfQuestions()} questions.");
        }
    }
}
