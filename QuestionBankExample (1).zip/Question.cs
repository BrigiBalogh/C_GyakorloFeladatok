﻿using System;

namespace QuestionBankExample
{
    abstract class Question
    {
        public string Id { get; }
        public virtual string Text { get; }
        public Question(string id, string text)
        {
            Id = id;
            Text = text;
        }

        public abstract bool CheckAnswer(string answer);
    }
}
