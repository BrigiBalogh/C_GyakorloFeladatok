﻿using System;
using System.Collections.Generic;

namespace QuestionBankExample
{
    class SingleChoiceQuestion : Question
    {
        List<string> _options;
        int _correctOptionIndex;

        public SingleChoiceQuestion(string id, string text, List<string> options, int correctOptionIndex):
            base(id, text)
        {
            _options = options;
            _correctOptionIndex = correctOptionIndex;
        }
        public override string Text
        {
            get
            {
                string questionText = base.Text;
                for (int i = 0; i < _options.Count; i++)
                {
                    questionText += $"\n  {i + 1}. {_options[i]}";
                }
                return questionText;
            }
        }

        public override bool CheckAnswer(string answer)
        {
            return int.Parse(answer) - 1 == _correctOptionIndex;
        }
    }
}
