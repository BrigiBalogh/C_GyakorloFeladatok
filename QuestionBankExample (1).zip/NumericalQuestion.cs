﻿using System;

namespace QuestionBankExample
{
    class NumericalQuestion : Question
    {
        private double _correctAnswer;
        public NumericalQuestion(string id, string text, double correctAnswer) :
            base(id, text)
        {
            _correctAnswer = correctAnswer;
        }
        public override bool CheckAnswer(string answer)
        {
            return double.Parse(answer) == _correctAnswer;
        }
    }
}
